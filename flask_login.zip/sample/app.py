from flask import Flask,render_template,request
from flask_cors import CORS

app = Flask(__name__)
CORS(app)

@app.route('/',methods=['GET'])
def welcome():
    return render_template('response.html',response='hello world')

@app.route('/login',methods=['GET'])
def login():
    return render_template('login.html')

@app.route('/login-form',methods=['POST'])
def login_form():
    name = request.form['name']
    phone = request.form['phone']
    # return [name,phone]
    return render_template('response.html',response=[name,phone])
 
@app.route('/add/<n1>/<n2>',methods=['GET'])
def add(n1,n2):
    n1,n2 = int(n1),int(n2)
    return {f'addition of {n1} and {n2}':n1+n2}
app.run() 